Indian Karigar Studio — Creator free funnel pack
================================================
Phone-friendly free tools for small Indian creators.

1) Creator_Content_Calendar_Free.html — interactive 7-day calendar (niche → week)
2) Creator_Content_Calendar_Free.md — markdown teaser
3) Creator_Caption_Formulas_Free.html — 10 caption formulas
4) Creator_Caption_Formulas_Free.md — markdown teaser

Soft CTA: Creator Starter Kit ₹149 → https://rzp.io/rzp/CSKC9mBV
DM keywords: CREATOR / CALENDAR / CAPTIONS
Support: indiankarigarstudio@gmail.com · +91 6283123493

Honest use only. Planning / writing templates — not growth guarantees.
Not affiliated with Canva Inc.
