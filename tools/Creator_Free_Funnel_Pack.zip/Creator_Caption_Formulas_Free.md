# 10 IG Caption Formulas for Indian Small Creators — FREE
Indian Karigar Studio · Creator Starter Kit funnel

**This file is FREE.** Ten original caption formulas / hooks you can paste into Canva (or Notes) and fill with your niche.  
Food · craft · coaching · local service — same skeleton, your words.

**Honest note:** These are writing templates, not “viral guarantees.” No fake follower counts, no invented sales. Use what fits your voice.

**How to paste into Canva:** Open your post/Reel design → click the text box → paste the filled caption into Canva’s caption field when you schedule, **or** keep this file open and copy the final line into Instagram’s caption box when you post. Canva designs hold the visual; Instagram holds the caption.

**Phone page:** open `Creator_Caption_Formulas_Free.html` in a browser (same 10 formulas).

**Keyword for DMs:** reply **CREATOR** or **CAPTIONS** on @indian.karigar.studio and we’ll send this free file again if you need it.

---

## 1) Hook → Proof → Soft ask (food / home cook / cloud kitchen)
```
[Hook one line people scroll-stop on]
[1–2 lines: what you cooked / what customers actually said — real words only]
[Soft ask: DM “MENU” / link in bio / “comment your favourite”]
```
**Example fill:** “Tuesday thali that tastes like home — no shortcuts. Regulars keep coming back for the dal tadka. Comment ‘THALI’ and I’ll send this week’s menu.”

---

## 2) Problem → Tiny fix → Offer (craft / handmade)
```
[Problem your buyer has in plain Hindi-English]
[One small tip they can try today — free value]
[Offer: what you sell + price band if honest]
```
**Example fill:** “Wall looks empty but framed prints feel expensive? Start with one A4 print at eye height above a side table. Hand-block prints from ₹___ — DM ‘PRINT’ for sizes.”

---

## 3) Before / After without fake numbers (coaching / skills)
```
[What felt stuck — no invented metrics]
[What you changed this week]
[Who it’s for + how to start]
```
**Example fill:** “I used to freeze on camera. Now I record one 45-second reel every morning before chai. If you’re a first-time coach in India, DM ‘START’ for my 7-day recording checklist (free).”

---

## 4) Local service — neighbourhood trust
```
[Area you serve]
[What you fix / deliver]
[How to book — phone / WhatsApp / form]
```
**Example fill:** “Noida Sector __ — same-day mixer / geyser check-up. Transparent call-out fee before I open the panel. WhatsApp ________ to book a slot.”

---

## 5) Myth → Truth → CTA
```
[Myth your niche believes]
[Honest truth in one sentence]
[What to do next]
```
**Example fill:** “Myth: you need a studio for food reels. Truth: a window + clean plate + phone works. Save this and shoot one dish tonight.”

---

## 6) Client story frame (real permission only)
```
[First name or initials + city — only with permission]
[What they wanted]
[What you delivered — no fake ₹ sales]
[Soft invite]
```
**Example fill:** “R. from Chandigarh wanted festival packaging that didn’t look generic. We designed 3 label options she could print locally. Want a similar pack? DM ‘LABEL’.”

---

## 7) Weekly strip caption (consistency without burnout)
```
Mon: [theme]
Tue: [theme]
Wed: [theme]
Thu: [theme]
Fri: [theme]
Which day do you want more of? Comment below.
```

---

## 8) Collab pitch (short, respectful)
```
Hi [Brand/Name] — I make [niche] content for [audience in India].
Idea: [one concrete collab]
Deliverable: [Reel / carousel / Stories]
My rate card / barter note: [honest]
If open, reply here or email ________
```

---

## 9) Offer drop (limited without fake scarcity)
```
[What]
[Who it’s for]
[Price + what’s included]
[How to pay / book]
[Real end date if you have one — else skip]
```
**Example fill:** “Creator Canva starter pack — 10 editable templates for small Indian creators. ₹149 · own use only. Pay → https://rzp.io/rzp/CSKC9mBV · support indiankarigarstudio@gmail.com”

---

## 10) Reel hook lines (first 1–2 seconds of text on screen)
```
1. “Stop rewriting the same caption every night.”
2. “If you sell locally in India, say the area in line 1.”
3. “One formula. Ten posts. Your voice.”
4. “Canva for the visual. This file for the words.”
5. “DM CREATOR — free caption formulas.”
```
Pick one. Put it as big text on your Reel cover. Caption below can use formulas 1–9.

---

## Quick Canva workflow
1. Duplicate your post template in Canva.
2. Swap `[Name]`, niche, price, photo.
3. Write the caption in Notes using one formula above.
4. Paste into Instagram when you publish (or Canva’s scheduler caption field).
5. First comment can hold the link so the caption stays clean.

---

## Want the full Creator Starter Kit?

**₹149** — 10 editable Canva templates for small Indian creators: intro, collab pitch, offer, testimonial frame, weekly strip, 3 highlight covers, 2 reel covers. Warm craft look. Own-use licence (no resell). Instant Canva link after payment.

Pay → https://rzp.io/rzp/CSKC9mBV  

Support: indiankarigarstudio@gmail.com · +91 6283123493  
IG: @indian.karigar.studio — DM **CREATOR** or **CAPTIONS** for this free file anytime.

© Indian Karigar Studio — free teaser. Original formulas for learning and posting. No fake testimonials or sales claims.
