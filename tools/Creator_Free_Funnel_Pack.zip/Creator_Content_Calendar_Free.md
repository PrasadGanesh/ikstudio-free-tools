# Free 7-Day Creator Content Calendar (teaser)

**Indian Karigar Studio** · planning ideas only — not growth or sales guarantees.

Pick a niche and sketch one post idea per day. Template types match the ₹149 Creator Starter Kit (intro, collab, offer, testimonial, weekly strip, reel covers).

## How to use
1. Open the phone page `Creator_Content_Calendar_Free.html` in a browser (preferred — interactive).
2. Choose niche: Food / Craft / Coaching / Local service.
3. Optional: type your brand name → **Build my week**.
4. Copy the week into Notes or Canva.

## Example week (Food / home cook) — placeholders only
| Day | Template type | Idea stub |
|-----|---------------|-----------|
| Mon | Intro post | Welcome + what you cook + soft “comment MENU” |
| Tue | Offer post | Tiffin / weekday slots + honest price band |
| Wed | Reel cover | Process hook (e.g. tadka pour) |
| Thu | Testimonial | One real buyer line (ask permission) |
| Fri | Weekly strip | Mon–Fri board visual |
| Sat | Collab pitch | Local brand tasting pitch |
| Sun | Reel cover | Prep / BTS for the week ahead |

Swap names, cities, and ₹ amounts with your real ones. No fake “sold out” or follower claims.

## Soft CTA
Want matching editable Canva layouts? **Creator Starter Kit** — 10 templates — ₹149 → https://rzp.io/rzp/CSKC9mBV  
Also free: caption formulas (`Creator_Caption_Formulas_Free.html`). DM **CREATOR** / **CALENDAR** / **CAPTIONS**.

Support: indiankarigarstudio@gmail.com · +91 6283123493
