Indian Karigar Studio — Free Solar Installer Pack (India)
=========================================================
Honest EXAMPLE tools only. VERIFY rates, subsidy, DISCOM rules, battery datasheets
and bank quotes before you promise a client anything. Not financial advice.

Contents
--------
1. Solar_Quote_Checklist_Free.md     — tick-list before you send numbers
2. Solar_Quote_Mini_Free_India.xlsx  — Checklist + Quick Size (open in Excel/Sheets/LibreOffice)
3. Solar_Quick_Size_Free.html        — phone Quick Size (same EXAMPLE math)
4. Solar_CFA_Subsidy_Free.html       — phone PM-Surya Ghar–style CFA sketch (EXAMPLE)
5. Solar_EMI_Loan_Free.html          — phone EMI / loan sketch (EXAMPLE; not a loan offer)
6. Solar_Net_Metering_Free.html (+ .md) — phone net-metering export-credit + docs checklist (EXAMPLE)
7. Solar_Battery_Hybrid_Free.html (+ .md) — phone battery / hybrid backup sizing + rough premium (EXAMPLE)
8. Installer_Client_WhatsApp_Scripts_Free.md — Hindi + English first-reply scripts
9. Sample_Client_Proposal_EXAMPLE.pdf (+ .html) — what a one-pager looks like (EXAMPLE numbers)

Paid upgrade (optional)
-----------------------
Full India workbook (14 sheets: sizing, margin, 25-yr payback, sensitivity, EMI,
net metering, battery, roof, soiling, subsidy, handover, quote compare, proposal)
₹499 → https://rzp.io/rzp/vDOX9lJ

Support: indiankarigarstudio@gmail.com · +91 6283123493
Keywords on Instagram / WhatsApp: CHECKLIST · CFA · SUBSIDY · EMI · LOAN · NETMETER · EXPORT · DISCOM · BATTERY · HYBRID · BACKUP
