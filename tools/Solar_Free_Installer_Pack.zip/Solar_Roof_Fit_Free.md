# Free Solar Roof Fit Sketch (India)

Phone HTML: `Solar_Roof_Fit_Free.html`

**What it does:** rough array fit check + mounting / BOS add-on cost from usable roof area, area per kWp, system size, walkway clearance, structure ₹/kWp and cable/SPD lumps — EXAMPLE defaults aligned to the paid Roof & Structure sheet.

**EXAMPLE smoke (defaults):** usable **38.15** sq m · **6.0** sq m/kWp · **3.815** kWp · walkway **10%** → area required **22.89** · walkway reserve **3.815** · effective **34.335** · headroom **11.445** · **Fit OK Yes** · structure **₹17,167.50** · BOS **₹20,000** · total add-on **₹37,167.50** · ~**₹9.74 / Wp** · shade-impact gen **5,073.95** kWh · lost **267.05** kWh (5% of 5,341).

**Honest limits:** not a PE structural stamp or MNRE approval; VERIFY fabricator, wind zone, waterproofing, earthing/SPD and today’s supplier quotes. Shade % is note-only. Soft CTA to full kit ₹499 → https://rzp.io/rzp/vDOX9lJ

Keywords: **ROOF** / **FIT** / **STRUCTURE** / **MOUNTING**
