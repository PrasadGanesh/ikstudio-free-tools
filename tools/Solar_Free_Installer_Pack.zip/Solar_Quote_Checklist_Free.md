> **Prefer the tickable Excel version:** `Solar_Quote_Mini_Free_India.xlsx` (Checklist + Quick Size EXAMPLE sheet) — attach that first; this .md is the fallback.

# Rooftop Solar Quote Checklist (India) — free one-pager
Indian Karigar Studio · honest checklist, not a design or bankable yield study

Use this before you send a homeowner quote. Tick what you already collected; fill gaps before promising payback.

## Site & load
- [ ] Average monthly bill (₹) **and** kWh from the bill (last 12 months if possible)
- [ ] DISCOM / circle name
- [ ] Single-phase or three-phase supply
- [ ] Usable shadow-free roof area (sq m) — paced or measured, not “whole terrace”
- [ ] Roof type (RCC / metal / tile) and any parapet / water-tank shadows
- [ ] Preferred panel orientation and known shading trees / neighbouring floors

## Commercial inputs (you must verify the day you quote)
- [ ] Current retail tariff the client pays (₹/kWh) — slab / ToD if applicable
- [ ] Export / net-metering credit rate for this DISCOM (₹/kWh) — **do not invent**
- [ ] Subsidy eligibility and amount for this client — **verify current scheme; leave ₹0 if unsure**
- [ ] Your supplier panel Wp + inverter size options + today’s unit costs
- [ ] GST treatment you will charge on this job

## Engineering defaults to sanity-check
- [ ] Specific yield (kWh/kWp/year) from PVWatts or PVGIS for this city — not a national average guess
- [ ] Self-consumption share (how much solar the house will use vs export)
- [ ] O&M assumption and inverter replacement year/cost
- [ ] Roof area needed per kWp for the mounting you actually use

## Client conversation (avoid over-promise)
- [ ] Payback shown as **estimate**, with yield and tariff sensitivity
- [ ] Subsidy and net-metering called out as subject to current rules
- [ ] Warranty split clear: panel / inverter / workmanship
- [ ] Who files the DISCOM / net-meter application
- [ ] If financing: bank rate and tenure are **bank quotes**, not your guarantee

## Optional next step
If you want the numbers filled into a sizing + parts-margin + 25-year payback + quote-compare + proposal workbook (India edition), the paid kit is ₹499: https://rzp.io/rzp/vDOX9lJ  
Support: indiankarigarstudio@gmail.com · +91 6283123493

© Indian Karigar Studio — free checklist. No fake savings claims.
