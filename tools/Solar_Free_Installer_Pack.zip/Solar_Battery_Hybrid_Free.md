# Free Solar Battery / Hybrid Sketch (India)

Phone HTML: `Solar_Battery_Hybrid_Free.html`

**What it does:** rough backup pack size + hybrid add-on cost from critical daily load, autonomy, DoD and RTE — EXAMPLE defaults aligned to the paid Battery - Hybrid sheet.

**EXAMPLE smoke (defaults):** 3 kWh/day × 0.5 day ÷ (0.9 × 0.9) → nameplate ~1.85 kWh → rounded **2.0 kWh** pack · pack cost **₹24,000** · hybrid+BMS **₹43,000** · total premium **₹67,000** · cycle-life years **16.0** (4000÷250).

**Honest limits:** not a bankable storage study; VERIFY usable kWh, hybrid compatibility, fire/DISCOM rules and today’s supplier quotes. Soft CTA to full kit ₹499 → https://rzp.io/rzp/vDOX9lJ

Keywords: **BATTERY** / **HYBRID** / **BACKUP**
