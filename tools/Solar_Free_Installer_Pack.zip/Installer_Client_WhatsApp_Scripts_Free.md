# Free — WhatsApp scripts for rooftop solar quotes (India)

Indian Karigar Studio · honest copy only. Use after you have **verified** site, tariff, yield and supplier costs. Do not paste EXAMPLE workbook numbers as a real quote.

Soft upsell: full India Quote & Payback Kit ₹499 → https://rzp.io/rzp/vDOX9lJ  
Support: indiankarigarstudio@gmail.com · +91 6283123493

---

## 1) First reply after a lead asks for a quote (Hindi + English)

**Hindi**
Namaste {Naam} ji — solar quote ke liye 4 cheezein chahiye:
1) Last 12 months ka average bill (₹) aur units (kWh)
2) DISCOM / circle naam
3) Roof pe usable shadow-free area (sq m) — paced/measured
4) Single-phase ya three-phase

Inke aate hi rough size + Year-1 bill-saving estimate bhej dunga. Subsidy / net-metering sirf current rules ke hisaab se, verify karke.

**English**
Hi {Name} — to quote rooftop solar I need:
1) Average monthly bill (₹) and kWh (ideally last 12 months)
2) DISCOM / circle
3) Usable shadow-free roof area (sq m), measured
4) Single-phase or three-phase

I’ll send a rough size + Year-1 self-use bill-saving estimate. Subsidy and net-metering only after we verify today’s rules for your circle.

---

## 2) Sending a rough size (before site visit)

Replace every {…} with **your** verified numbers. Never send EXAMPLE defaults.

Namaste {Naam} ji —

Rough screening (not a final design):
• Size: ~{kWp} kWp · ~{panels} × {Wp}W panels  
• Roof fit: usable area {m2} sq m (walkways reserved)  
• Year-1 gen (EXAMPLE city yield {yield} kWh/kWp — verify for your city): ~{kWh} kWh  
• Year-1 bill saving on **self-used** units only @ ₹{tariff}/kWh: ~₹{saving}  
• Export credit / subsidy / EMI: **not included** until we verify DISCOM + scheme + bank rate

Next step: 20–30 min site / video walk of the roof, then a full quote with parts, margin, payback and proposal.

---

## 3) After site visit — invite to the full proposal

Site notes locked. I’ll send:
• Parts list + your margin  
• 25-year savings / payback (with sensitivity)  
• Optional EMI sketch (bank rate is the bank’s, not my guarantee)  
• Net-metering / subsidy checklist for your DISCOM  
• One-page client proposal you can forward

If you want the same workbook your installer team can reuse on every job: India Quote & Payback Kit ₹499 → https://rzp.io/rzp/vDOX9lJ

---

## 4) Honesty lines (paste when a client pushes “guaranteed payback”)

• Payback is an **estimate** — yield, tariff slabs and self-use change it.  
• Subsidy and net-metering follow **current** central/state/DISCOM rules; we re-check the week we apply.  
• Panel / inverter / workmanship warranties are separate — I’ll list each on the proposal.  
• Financing rate and tenure come from the **bank / NBFC**, not from me.

---

## 5) Free tools with this pack

1. `Solar_Quote_Mini_Free_India.xlsx` — checklist + Quick Size formulas  
2. `Solar_Quick_Size_Free.html` — same Quick Size math, works on a phone browser  
3. `Sample_Client_Proposal_EXAMPLE.pdf` — what the paid kit’s proposal looks like (EXAMPLE client only)

Keyword on Instagram: **CHECKLIST**
