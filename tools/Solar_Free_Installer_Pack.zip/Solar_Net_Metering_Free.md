# Free Solar Net Metering Sketch (India) — Indian Karigar Studio

Phone HTML preferred: `Solar_Net_Metering_Free.html`

**What this is:** a rough annual export-credit sketch + DISCOM docs checklist.  
**What this is not:** approval, sanction, bank credit, or a guaranteed ₹ amount.

## EXAMPLE defaults (aligned to paid kit Inputs)
- Export credit: **₹3.5 / kWh** (VERIFY with DISCOM)
- Year-1 generation: **5,341 kWh**
- Self-use share: **0.7** → suggested export **1,602.3 kWh**
- Estimated annual export credit (if net-metering = Yes): **₹5,608.05**
- Subsidy on file: **₹0** (leave 0 when unsure)

Formula: `credit = export_kWh × export_₹/kWh` only when net-metering is Yes; else ₹0.

## Docs checklist (workflow helper — not legal advice)
- [ ] Aadhaar
- [ ] Electricity bill (recent)
- [ ] Property proof
- [ ] Net-meter application form
- [ ] DISCOM approval / sanction
- [ ] Bank KYC for subsidy transfer

## Full workbook (optional)
Sizing + margin + 25-yr payback + EMI + net metering + more — ₹499 → https://rzp.io/rzp/vDOX9lJ

Support: indiankarigarstudio@gmail.com · +91 6283123493  
Keywords: **NETMETER** / **EXPORT** / **DISCOM**
