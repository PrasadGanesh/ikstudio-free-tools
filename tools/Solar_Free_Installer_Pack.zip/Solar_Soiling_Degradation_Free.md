# Free Solar Soiling & Degradation Sketch (India)

Phone HTML: `Solar_Soiling_Degradation_Free.html`

**What it does:** rough soiling-loss kWh + ₹ impact, annual cleaning O&M, optional LID note, and panel degradation remaining-fraction snapshot (years 1/5/10/15/25) — EXAMPLE defaults aligned to the paid Soiling - Degradation sheet (Inputs-linked). Does **not** overwrite Inputs Year-1 gen / yield / degradation / O&M.

**EXAMPLE smoke (defaults):** Year-1 gen **5,341** kWh · self-use **0.7** · tariff **₹8**/kWh · export **₹3.5**/kWh · soiling **4%** · cleaning **6×₹800** · LID **1.5%** · degradation **0.5%/yr** → soiled gen **5,127.36** · lost **213.64** kWh · self-use ₹ **1,196.38** · export ₹ **224.32** · combined ~**₹1,420.71** · cleaning O&M **₹4,800**/yr · remaining fractions ≈ **1.0 / 0.9801 / 0.9559 / 0.9322 / 0.8867**.

**Honest limits:** not a bankable soiling study, P50/P90, or Smart Helio / proprietary model; VERIFY site soiling, cleaning rates and module datasheet. Soft CTA to full kit ₹499 → https://rzp.io/rzp/vDOX9lJ

Keywords: **SOILING** / **CLEANING** / **DEGRADATION** / **DUST**
