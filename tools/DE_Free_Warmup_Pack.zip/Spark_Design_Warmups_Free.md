# Free Spark Design Warm-ups — Indian Karigar Studio

Five original interview sketches with short worked answers (PySpark-style mental models).
**Not** a company interview bank and not employer material — written for learning.
Assume Spark 3.x with Adaptive Query Execution available unless noted.

Practice context (fictional): “NadiHaul” logistics lake — practice only.

---

## SP1 · Easy — Tiny files after a nightly landing

**Prompt.** Bronze lands ~40k tiny Parquet files every night. Silver jobs crawl. What do you change on write?

**Worked answer.** Size files on write (`repartition`/`coalesce`, `maxRecordsPerFile`, aim ~128–512 MB). Compact existing tiny files on a schedule (`OPTIMIZE` / rewrite job). Interview line: small files kill listing + task scheduling.

---

## SP2 · Easy/Med — cache vs checkpoint

**Prompt.** Long silver pipeline fails after 90 minutes; restart rebuilds the whole DAG. When `cache`/`persist` vs `checkpoint`?

**Worked answer.** Persist = reuse inside one job/session (lineage kept). Checkpoint = cut lineage for recovery (writes durable path). Don’t checkpoint every step.

---

## SP3 · Med — Python UDF tax

**Prompt.** Row Python UDF on 80 GB is 6× slower. Cost + first fix?

**Worked answer.** Name serialization + lost Catalyst/Arrow benefits. Prefer built-in expressions / higher-order functions; then pandas_udf; last resort JVM UDF or preprocess.

---

## SP4 · Med — Nested JSON without schema roulette

**Prompt.** Gzipped nested JSON; `inferSchema` flaky/slow. Design the read path.

**Worked answer.** Explicit versioned schema; `PERMISSIVE` + `_corrupt` quarantine (or `FAILFAST` in CI). Inference is for exploration only.

---

## SP5 · Med — AQE on, plan still wrong

**Prompt.** Small dimension still shuffles. What do you check?

**Worked answer.** Spark UI SQL tab: BroadcastHashJoin vs SortMergeJoin; size stats; deliberate `F.broadcast` when build side fits. AQE helps; it doesn’t replace size judgment.

---

## Full pack (paid)

Deeper Spark chapter (**different** prompts) · SQL windows · Airflow · system design · energy/telemetry · pandas/Polars · dbt · Kafka · DQ · cloud SQL · lakehouse · take-home · testing/CI · security/governance · SQLite drills · mock day — **₹499** → https://rzp.io/rzp/pi8ainEA

Also free: phone SQL warm-ups HTML. DM **SPARK** / **WARMUP**.

Support: indiankarigarstudio@gmail.com · +91 6283123493
