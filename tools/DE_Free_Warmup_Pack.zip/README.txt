Indian Karigar Studio — Free DE Warm-up Pack
============================================

Contents (all free teasers; original practice for learning only):
- SQL_Window_Warmups_Free.html  — phone quiz, 5 SQL window Qs
- SQL_Window_Warmups_Free.md    — same 5 Qs, markdown
- Spark_Design_Warmups_Free.html — phone quiz, 5 Spark design sketches
- Spark_Design_Warmups_Free.md   — same 5 sketches, markdown
- Airflow_Design_Warmups_Free.html — phone quiz, 5 Airflow design sketches
- Airflow_Design_Warmups_Free.md   — same 5 sketches, markdown
- README.txt (this file)

Keywords for Instagram / WhatsApp DM: WARMUP · SQL · SPARK · AIRFLOW

Full paid pack (₹499): https://rzp.io/rzp/pi8ainEA
Support: indiankarigarstudio@gmail.com · +91 6283123493

Honest claims only — not a company interview bank; not employer material.
