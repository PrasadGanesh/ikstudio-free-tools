# SQL Window Warm-ups — FREE teaser (5 questions)
Indian Karigar Studio · Data Engineering Interview Pack

**This file is a FREE teaser.** Five original warm-up questions with short worked answers.  
Full pack (SQL · Spark · Airflow · system design · energy/telemetry · pandas/Polars · dbt · Kafka/streaming · DQ/observability · cloud SQL/warehousing · SQLite drills · mock interview day) — **₹499** → https://rzp.io/rzp/pi8ainEA

**Honest note:** Original practice questions written for learning and interview prep. Not employer material, not from any company interview bank, not Smart Helio IP. Dialects are SQLite-friendly; patterns translate to Postgres / BigQuery / Spark SQL.

**How to use:** Attempt cold, then check the answer. Schema below is fictional retail.

---

## Schema (simple)

```sql
-- customers(customer_id, city, signup_date)
-- orders(order_id, customer_id, order_date, amount_inr, status)
-- status values: 'paid', 'cancelled', 'refunded'
```

---

## W1 — Running spend per customer (Easy)

**Problem.** For each paid order, show the customer’s running total of `amount_inr` ordered by `order_date` (and `order_id` as tie-break).

**Worked answer.**
```sql
SELECT
  customer_id,
  order_id,
  order_date,
  amount_inr,
  SUM(amount_inr) OVER (
    PARTITION BY customer_id
    ORDER BY order_date, order_id
    ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
  ) AS running_spend
FROM orders
WHERE status = 'paid'
ORDER BY customer_id, order_date, order_id;
```

**Why.** Classic running total. Explicit `ROWS` frame keeps peers with the same timestamp from sharing one bucket unexpectedly.

---

## W2 — Rank of each order inside the customer (Easy)

**Problem.** Within each `customer_id`, rank paid orders by `amount_inr` descending. Show both `RANK` and `DENSE_RANK`. Break amount ties with earlier `order_date`.

**Worked answer.**
```sql
SELECT
  customer_id,
  order_id,
  amount_inr,
  order_date,
  RANK() OVER (
    PARTITION BY customer_id
    ORDER BY amount_inr DESC, order_date ASC
  ) AS rnk,
  DENSE_RANK() OVER (
    PARTITION BY customer_id
    ORDER BY amount_inr DESC, order_date ASC
  ) AS dense_rnk
FROM orders
WHERE status = 'paid';
```

**Why.** Interviewers love “what’s the difference?” — `RANK` leaves gaps after ties; `DENSE_RANK` does not. Say it out loud.

---

## W3 — Days since previous paid order (Med)

**Problem.** For every paid order, compute days since that customer’s previous paid order. First order for a customer should show NULL days.

**Worked answer (SQLite).**
```sql
SELECT
  customer_id,
  order_id,
  order_date,
  ROUND(
    julianday(order_date) - julianday(prev_date),
    1
  ) AS days_since_prev
FROM (
  SELECT
    customer_id,
    order_id,
    order_date,
    LAG(order_date) OVER (
      PARTITION BY customer_id
      ORDER BY order_date, order_id
    ) AS prev_date
  FROM orders
  WHERE status = 'paid'
) t;
```

**Why.** Recency / inter-purchase gap = `LAG` on the date column. In Postgres: `(order_date - prev_date)`.

---

## W4 — Each order’s share of the customer’s paid total (Med)

**Problem.** For each paid order, show `amount_inr` and the fraction it represents of that customer’s all-time paid total (0–1).

**Worked answer.**
```sql
SELECT
  customer_id,
  order_id,
  amount_inr,
  ROUND(
    amount_inr * 1.0
      / SUM(amount_inr) OVER (PARTITION BY customer_id),
    4
  ) AS share_of_customer_total
FROM orders
WHERE status = 'paid';
```

**Why.** Window `SUM` without `ORDER BY` is the full-partition total — handy for “% of group” without a self-join.

---

## W5 — Latest paid order per customer, then flag stale (Med)

**Problem.** Return only each customer’s most recent paid order. Add a flag `is_stale` = 1 if that order is more than 90 days before a fixed as-of date `'2026-11-05'`.

**Worked answer.**
```sql
SELECT
  customer_id,
  order_id,
  order_date,
  amount_inr,
  CASE
    WHEN julianday('2026-11-05') - julianday(order_date) > 90
    THEN 1 ELSE 0
  END AS is_stale
FROM (
  SELECT
    customer_id,
    order_id,
    order_date,
    amount_inr,
    ROW_NUMBER() OVER (
      PARTITION BY customer_id
      ORDER BY order_date DESC, order_id DESC
    ) AS rn
  FROM orders
  WHERE status = 'paid'
) t
WHERE rn = 1;
```

**Why.** “Latest row per group” = `ROW_NUMBER` + filter. Churn / reactivation screens often start here. Change the as-of date to “today” in a real warehouse.

---

## Want more?

Full **Data Engineering Interview Pack** (₹499): 12 SQL window questions (different from these warm-ups), Spark design, Airflow design, DE system design, practice dataset + cheatsheet, and a mock interview day plan.

Pay → https://rzp.io/rzp/pi8ainEA  
Support: indiankarigarstudio@gmail.com · +91 6283123493

© Indian Karigar Studio — free teaser. Original practice content for learning only.
