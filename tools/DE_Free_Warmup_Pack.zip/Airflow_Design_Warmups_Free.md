# Free Airflow Design Warm-ups — Indian Karigar Studio

Five original interview sketches with short worked answers (Airflow 2.x mental models).
**Not** a company interview bank and not employer material — written for learning.
Assume Airflow 2.x with Scheduler + Triggerer unless noted.

Practice context (fictional): “NadiHaul” logistics platform — practice only.

---

## AF1 · Easy/Med — catchup=True after weeks offline

**Prompt.** Daily DAG paused 3 weeks; unpaused with `catchup=True` and old `start_date`. What happens, and how do you recover?

**Worked answer.** Scheduler schedules ~21 catch-up runs → thundering herd on warehouse/API. Pause; set `catchup=False` or raise `start_date`; clear only intentional intervals; prefer a bounded one-off backfill DAG with `max_active_runs=1`. Interview line: catchup is a time machine — treat unpausing as a capacity event.

---

## AF2 · Med — Pools vs starving other DAGs

**Prompt.** Heavy extracts hog worker slots; other teams’ short DAGs queue for hours. Fix?

**Worked answer.** Put expensive tasks in a pool with limited slots; also cap `max_active_runs` / `max_active_tasks` on your DAG. Pools budget scarce external capacity; DAG limits budget your fan-out.

---

## AF3 · Med — Deferrable sensor vs poking FileSensor

**Prompt.** Classic FileSensor poke waits 6 hours and occupies a worker. What changes?

**Worked answer.** Use a deferrable / async sensor so the worker slot is released while waiting. Requires a healthy Triggerer. Interview line: poke sensors rent a worker; deferrable sensors rent a Triggerer wakeup.

---

## AF4 · Med — Dynamic task mapping over files

**Prompt.** Some nights 3 hub files, some nights 40. Static N parallel tasks fails. Design?

**Worked answer.** `@task` that lists keys → `load_one.expand(key=keys)` (Airflow 2.3+). Empty list → zero mapped instances. Pair with `max_active_tasks` / pools so a 200-file night doesn’t melt the cluster.

---

## AF5 · Med — Dataset / TriggerDagRun decoupling

**Prompt.** Three consumers hard-wire `ExternalTaskSensor` on producer task_ids; refactors break sensors. Decouple?

**Worked answer.** Producer declares a Dataset outlet; consumers `schedule=[Dataset(...)]` (Airflow 2.4+). Or `TriggerDagRunOperator` with `conf` when you need an explicit kick. Contract the data (or the trigger), not private task names.

---

## Full pack (paid)

Deeper Airflow chapter (**different** prompts: idempotent loads, sensor vs schedule, backfill, SLAs/retries, XCom, task groups/branching) · SQL windows · Spark · system design · energy/telemetry · pandas/Polars · dbt · Kafka · DQ · cloud SQL · lakehouse · take-home · testing/CI · security/governance · SQLite drills · mock day — **₹499** → https://rzp.io/rzp/pi8ainEA

Also free: phone SQL + Spark warm-ups. DM **AIRFLOW** / **WARMUP**.

Support: indiankarigarstudio@gmail.com · +91 6283123493
